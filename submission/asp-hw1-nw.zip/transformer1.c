#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <locale.h>

#define BUFFER_SIZE 1024
#define LINE_SIZE 512

void split_line(char *line, char *fields[]) {
    int cur_field = 0;
    fields[cur_field++] = line;

    for (int i = 0; line[i] != '\0'; i++) {
        if (line[i] == ' ' && line[i-1] == ',') {
            line[i-1] = '\0'; // replace the comma before whitespace with null terminator
            fields[cur_field++] = &line[i + 1]; // start next line at character after the whitespace
        }
    }
}

// https://www.vervecopilot.com/hot-blogs/strip-string-in-c-interviews#:~:text=Can%20you%20see%20a%20concise%20example%20of,manipulation%2C%20correct%20null%2Dtermination%2C%20and%20efficient%20one%2Dpass%20behavior.
void removeCharacter(char* str, char charToRemove) {
    char *src, *dst;
    for (src = dst = str; *src; src++) {
        if (*src != charToRemove) {
            *dst++ = *src;
        }
    }
    *dst = '\0'; // Null-terminate the new string
}

void process_line(char *line) {
    char *fields[7]; 
    split_line(line, fields);

    char *agentName = fields[0];
    char *agentID   = fields[1];
    char *transID   = fields[2];
    char *stateID   = fields[3];
    char *origPrice = fields[4];
    char *salePrice = fields[5];
    char *custRate  = fields[6];
    
    // Remove commas for calculation purposes.
    removeCharacter(salePrice, ',');
    removeCharacter(origPrice, ',');

    double gain = strtod(salePrice, NULL) - strtod(origPrice, NULL);
    double sale = strtod(salePrice, NULL);
    char out[256];
    int len;

    // To deal with weird formatting of numbers
    char gain_str[32];
    setlocale(LC_NUMERIC, ""); // automatically converts numbers into standard format with commas
    if (gain > 0) {
        snprintf(gain_str, sizeof(gain_str), "+%'.2f", gain);
    } else if (gain < 0) {
        snprintf(gain_str, sizeof(gain_str), "%'.2f", gain);  // negative already has `-`
    } else {  // gain == 0
        snprintf(gain_str, sizeof(gain_str), "%'.2f", gain);  // just 0.00
    }

    
    // write to stdout 
    len = snprintf(out, sizeof(out),
        "%s, %s, %s, %s, %'.2f, %s\n",
        agentName, agentID, transID, stateID, sale, gain_str
    );
    write(1, out, len);

    // write to stderr
    double rate = strtod(custRate, NULL);
    len = snprintf(out, sizeof(out),
        "%s, %s, %.1f\n",
        agentID, stateID, rate
    );
    write(2, out, len);
}


int main() {
    // File descriptor 0: stdin
    // stdin automatically opened when process starts
    char inbuf[BUFFER_SIZE];
    char line[LINE_SIZE];
    int line_pos = 0;
    ssize_t bytes_read;

    // Split stdin by line
    while ((bytes_read = read(0, inbuf, BUFFER_SIZE)) > 0) {
        for (ssize_t i = 0; i < bytes_read; i++) {
            if (inbuf[i] == '\n') {
                line[line_pos] = '\0';
                process_line(line);
                line_pos = 0;
            } else {
                line[line_pos++] = inbuf[i];
            }
        }
    }
    
    return 0;
}

